<?php
 session_start();
 require "../includes/dbhandler.inc.php";
 $exam_cat=$_GET["ecat"];
 $_SESSION["catofexam"]=$exam_cat;
 $res=mysqli_query($conn, "select * from exam_category where category='$exam_cat'");
 while($row=mysqli_fetch_array($res)){
	 $_SESSION["timeofexam"]=$row["examTime"];
 }
 date_default_timezone_set('Asia/Kolkata');
 $date=date("Y-m-d H:i:s");
 $_SESSION["endtime"]= date("Y-m-d H:i:s", strtotime($date."+ $_SESSION['timeofexam'] minutes"));
 $_SESSION["exam_start"]="yes";
 
?>